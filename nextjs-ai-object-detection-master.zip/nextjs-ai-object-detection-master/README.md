# AI Object Detector with Next js 14, Tailwind CSS, Tenserflow, React 
## [Click Here to Watch Full tutorial on Youtube](https://www.youtube.com/watch?v=6YFbBcxWdKU)

![object detector](https://github.com/piyush-eon/nextjs-ai-object-detection/assets/51760520/be2d9e63-bacd-4cae-bf0e-f3728761d678)
